//go:build !android
// +build !android

package main

func log_init() {
}
